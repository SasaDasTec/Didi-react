import React from 'react';

import { TelaAnoCurso } from '@/components/tela-ano-curso';

export default function TerceiroAnoScreen() {
  return (
    <TelaAnoCurso
      ano="3o ano"
      certificado="Tecnico em Informatica para Internet"
      descricao="Diploma de ensino medio com habilitacao profissional tecnica concluido ao finalizar as tres series."
    />
  );
}
