import { Tabs } from "expo-router";
import React from "react";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Colors } from "@/constants/theme";
import { useColorScheme } from "@/hooks/use-color-scheme";

export default function TabLayout() {
  const colorScheme = useColorScheme();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? "light"].tint,
        headerShown: false,
        tabBarButton: HapticTab,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "1 ano",
          tabBarIcon: ({ color }) => (
            <IconSymbol size={28} name="1.circle" color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="explore"
        options={{
          title: "2 ano",
          tabBarIcon: ({ color }) => (
            <IconSymbol size={28} name="2.circle" color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="terceiro"
        options={{
          title: "3 ano",
          tabBarIcon: ({ color }) => (
            <IconSymbol size={28} name="3.circle" color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
