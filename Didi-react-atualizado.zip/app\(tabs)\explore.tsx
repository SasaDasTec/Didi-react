import React from 'react';

import { TelaAnoCurso } from '@/components/tela-ano-curso';

export default function SegundoAnoScreen() {
  return (
    <TelaAnoCurso
      ano="2o ano"
      certificado="Desenvolvedor de Aplicacoes Web e Mobile"
      descricao="Qualificacao profissional tecnica de nivel medio concluida na segunda serie do curso."
    />
  );
}
