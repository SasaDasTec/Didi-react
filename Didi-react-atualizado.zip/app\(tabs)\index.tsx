import React from 'react';

import { TelaAnoCurso } from '@/components/tela-ano-curso';

export default function PrimeiroAnoScreen() {
  return (
    <TelaAnoCurso
      ano="1o ano"
      certificado="Auxiliar Tecnico de Informatica para Internet"
      descricao="Qualificacao profissional tecnica de nivel medio concluida na primeira serie do curso."
    />
  );
}
